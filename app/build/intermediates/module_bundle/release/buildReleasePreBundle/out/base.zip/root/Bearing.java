/*
 * A Bearing
 */

public class Bearing {

	private double distanceFromLeftEndOfBeam_m;

	Bearing(double distanceFromLeftEndOfBeam_m) {
		this.distanceFromLeftEndOfBeam_m = distanceFromLeftEndOfBeam_m;
	}

	public double getDistanceFromLeftEndOfBeam_m() {
		return distanceFromLeftEndOfBeam_m;
	}
}
