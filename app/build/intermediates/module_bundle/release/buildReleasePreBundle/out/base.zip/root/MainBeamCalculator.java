/**
 * A simple driver
 * 
 * Create a beam, add loads, solve.....
 * 
 */

public class MainBeamCalculator {
	public static void main(String[] args) {

		Beam myBeam = new Beam(12);

		myBeam.addBearing(new Bearing(0));
		myBeam.addBearing(new Bearing(9));

		myBeam.addLoad(new Load(-10, 3, 0));
		myBeam.addLoad(new Load(-5, 5, 0));

		Result result = Solve.getResults(myBeam);

		if (result.getErrorCount() == 0) {
			System.out.println("Beam. Loads:" + myBeam.getNumberOfLoads());
			System.out.println("Left bearing:" + result.getResultingForceAtLeftBearing_N() + " N. Right bearing:"
					+ result.getResultingForceAtRightBearing_N() + " N.");
		} else
			System.out.println("Errors:" + result.getErrorCount());
	}
}
