/**
 * A beam.
 * 
 * @author Berthold
 *
 */

import java.util.ArrayList;
import java.util.List;

public class Beam {
	private double lengthOfBeam_m;
	private List<Bearing> support;
	private int numberOfBearings;
	private List<Load> stress;

	/*
	 * Create a beam
	 */

	public Beam(double lengthOfBeam_m) {
		this.lengthOfBeam_m = lengthOfBeam_m;
		support = new ArrayList<Bearing>();
		numberOfBearings = 0;
		stress = new ArrayList<Load>();
	}

	/*
	 * Add load
	 */

	public void addLoad(Load load) {
		stress.add(load);
	}

	/*
	 * Add bearing
	 */

	public void addBearing(Bearing bearing) {
		support.add(bearing);
	}

	/*
	 * Check if load/ bearing is inside length of beam
	 */

	public boolean isInsideOfBeamLength(double distanceFromLeftEndOfBeam_m) {
		if (distanceFromLeftEndOfBeam_m >= 0 && distanceFromLeftEndOfBeam_m <= lengthOfBeam_m)
			return true;
		else
			return false;
	}

	/*
	 * Getters
	 */

	public Load getLoad(int atIndex) {
		return stress.get(atIndex);
	}

	public double getLength() {
		return lengthOfBeam_m;
	}

	public int getNumberOfLoads() {
		return stress.size();
	}

	public int getNumberOfBearings() {
		return numberOfBearings;
	}

	public Bearing getBearing(int bearingIndexFromLeftEndOfBeam) {
		return support.get(bearingIndexFromLeftEndOfBeam);

	}

}
