/**
 * Solves a simply supported beam with single and/ or line loads.
 * 
 * Beam has a statically determined support configuration.
 * Bearings may be placed arbitrary inside length of beam. 
 * 
 * Solver has to check for valid initial conditions.
 * If any of the expected initial conditions are not met (e.g. bearing not inside beam length) result is set to 0
 * and number of errors is increased. Calling class must deal with errors accordingly.
 * 
 * Force, leading sign: (+) Force acts upwards (-) Force acts downwards.
 * Torque, leading sing (+) Clockwise (-) Anti- clockwise.
 * 
 * Result: Resulting forces at the bearings can point up or downwards. 
 * A negative result means that the force points in the opposite direction of the
 * acting force. So, (-) means "upwards" regarding the result.
 * 
 * 
 * 
 *         F1          F2                 Fn
 *         |           |                  |
 * 		-------0--------------------0--------------
 * 			   A			        A
 *          (F_Left)               (F_Right)
 *          
 *             |---------- l -------|          
 *          
 *          
 *      |
 *      |-l1---|
 *      |
 *      |-------------------l2------|    
 * 
 *      |x1|
 *      |
 *      |--------x2----|
 *      |
 *      |----------------xn---------------|
 * 
 * 
 * Solver calculates from left to right by solving the following equation:
 * 		TorqueSumAtRightBearing=0=F_Leftxl-F1x(l2-x1)-F2x(l2-x2)-....-Fn(l2-xn)
 * 
 * Resulting force at right bearing is calculated by solving this equation:
 * 		SummOfVerticalForces=0=F_Left-F1-F2-....-Fn+F_Right
 *
 * @author Berthold
 *
 */

public class Solve {

	public static Result getResults(Beam beam) {

		/*
		 * Init
		 */

		Result result = new Result();
		int errorCount = 0;
		double spaceBetweenBearings_m = 0;
		double torqueSum = 0;
		double loadSum = 0;
		Load load;

		/*
		 * Get and check bearings
		 */

		Bearing leftBearing = beam.getBearing(0);
		Bearing rightBearing = beam.getBearing(1);
		if (beam.isInsideOfBeamLength(leftBearing.getDistanceFromLeftEndOfBeam_m())
				&& beam.isInsideOfBeamLength(rightBearing.getDistanceFromLeftEndOfBeam_m())) {
			spaceBetweenBearings_m = Math
					.abs(leftBearing.getDistanceFromLeftEndOfBeam_m() - rightBearing.getDistanceFromLeftEndOfBeam_m());
		} else
			result.setErrorCount(++errorCount);

		/*
		 * Get and check loads, calculate resultant forces at left and right
		 * bearing
		 */

		for (int i = 0; i <= beam.getNumberOfLoads() - 1; i++) {
			load = beam.getLoad(i);
			
			if (beam.isInsideOfBeamLength(load.getDistanceFromLeftEndOfBeam_m()) && beam
					.isInsideOfBeamLength(load.getDistanceFromLeftEndOfBeam_m() + load.getLengthOfLineLoad_m())) {
				if (load.getLengthOfLineLoad_m() == 0) {

					// Load is a single load
					loadSum = loadSum + load.getForce_N();
					torqueSum = torqueSum + load.getForce_N()
							* (rightBearing.getDistanceFromLeftEndOfBeam_m() - load.getDistanceFromLeftEndOfBeam_m());
				} else {
					// Load is line load
					double resultandForce_N = load.getForce_N() * load.getLengthOfLineLoad_m();
					double distanceOfResultandForceFromLeftEndOfbeam_m = (load.getDistanceFromLeftEndOfBeam_m())
							+ load.getLengthOfLineLoad_m() / 2;
					loadSum = loadSum + resultandForce_N;
					torqueSum = torqueSum + resultandForce_N * (rightBearing.getDistanceFromLeftEndOfBeam_m()
							- distanceOfResultandForceFromLeftEndOfbeam_m);
				}
			} else
				result.setErrorCount(++errorCount);
		}
		if (errorCount == 0) {
			result.setResultingForceAtLeftBearingBearing_N(-1 * torqueSum / spaceBetweenBearings_m);
			result.setResultingForceAtRightBearing_N(-1 * loadSum - result.getResultingForceAtLeftBearing_N());
		}
		return result;
	}
}
