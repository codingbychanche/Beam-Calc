/**
 * Result 
 * 
 * TODO: Implement error description....
 * 
 * @author Berthold
 *
 */
public class Result {
	private int errorCount;
	private double resultingForceAtLeftBearing_N, resultingForceAtRightBearing_N;

	public int getErrorCount() {
		return errorCount;
	}

	public void setErrorCount(int errorCount) {
		this.errorCount = errorCount;
	}

	public double getResultingForceAtRightBearing_N() {
		return resultingForceAtRightBearing_N;
	}

	public void setResultingForceAtRightBearing_N(double resultingForceAtRightBearing_N) {
		this.resultingForceAtRightBearing_N = resultingForceAtRightBearing_N;
	}

	public double getResultingForceAtLeftBearing_N() {
		return resultingForceAtLeftBearing_N;
	}

	public void setResultingForceAtLeftBearingBearing_N(double resultingForceAtLeftBearing_N) {
		this.resultingForceAtLeftBearing_N = resultingForceAtLeftBearing_N;
	}
}



