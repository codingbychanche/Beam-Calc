/**
 * Load
 * 
 * Load acting downwards (-) Load acting upwards (+)
 * 
 * @author Berthold
 *
 */
public class Load {
	private double force_N;
	private double distanceFromLeftEndOfBeam_m;
	private double lengthOfLineLoad_m;

	/*
	 * Create a single force or a line load.
	 */

	public Load(double force_N, double distanceFromLeftEndOfBeam_m, double lengthOfLineLoad_m) {
		this.force_N = force_N;
		this.distanceFromLeftEndOfBeam_m = distanceFromLeftEndOfBeam_m;
		this.lengthOfLineLoad_m = lengthOfLineLoad_m;
	}

	/*
	 * Getters
	 */

	public double getForce_N() {
		return force_N;
	}

	public double getDistanceFromLeftEndOfBeam_m() {
		return distanceFromLeftEndOfBeam_m;
	}

	public double getLengthOfLineLoad_m() {
		return lengthOfLineLoad_m;
	}
}
